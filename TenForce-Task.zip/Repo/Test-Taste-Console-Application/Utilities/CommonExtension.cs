﻿using System.Collections.Generic;
using System.Linq;
using Test_Taste_Console_Application.Domain.DataTransferObjects;

namespace Test_Taste_Console_Application.Utilities
{
    public static class CommonExtension
    {
        /// <summary>
        /// Moon average extention method.
        /// </summary>
        /// <param name="Moons">Moon collection</param>
        /// <returns>float average value</returns>
        public static float MoonAverage(this ICollection<MoonDto> Moons)
        {
            return Moons.Average(item => item.MassValue);
        }
    }
}
