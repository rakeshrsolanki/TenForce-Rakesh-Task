﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Test_Taste_Console_Application.Domain.DataTransferObjects;
using Test_Taste_Console_Application.Utilities;

namespace Test_Taste_Console_Application.Domain.Objects
{
    public class Planet
    {
        //private readonly IMapper _mapper;
        public string Id { get; set; }
        public float SemiMajorAxis { get; set; }
        public ICollection<Moon> Moons { get; set; }
        public float AverageMoonGravity
        {
            //New code - set and get property initialized
            get; set;
            //Old Code.
            //get => 0.0f;
        }

        //public Planet(IMapper mapper)
        //{
        //    _mapper=mapper;
        //}

        public Planet(PlanetDto planetDto)
        {
            try
            {
                Id = planetDto.Id;
                SemiMajorAxis = planetDto.SemiMajorAxis;
                Moons = new Collection<Moon>();
                if (planetDto.Moons != null)
                {
                    //AutoMapper
                    //Moons = _mapper.Map<ICollection<Moon>>(planetDto.Moons);
                    //AverageMoonGravity = Moons.Average(item => item.MassValue);

                    //New code - Solution - 2 Take float variable for count all mass value.
                    //float massValue = 0;

                    foreach (MoonDto moonDto in planetDto.Moons)
                    {
                        //Solution - 2 -Sum of all mass value.
                        //massValue += moonDto.MassValue;
                        Moons.Add(new Moon(moonDto));
                    }

                    //Solution -1 - Using Linq Average function.
                    AverageMoonGravity = planetDto.Moons.Average(item => item.MassValue);

                    //New code -get average of moon and sent in the average mooon property.
                    //Solution - 2
                    //AverageMoonGravity = massValue / planetDto.Moons.Count;


                    //Solution -3 - Using extention method
                    //AverageMoonGravity = planetDto.Moons.MoonAverage();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error Message:{ex.Message}");
                throw;
            }

        }

        public Boolean HasMoons()
        {
            return (Moons != null && Moons.Count > 0);
        }
    }
}
